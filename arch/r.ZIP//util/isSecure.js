export default function isSecure({ protocol }) {
    return protocol === "https:";
}
