package main

import (
	"compress/flate"
	"fmt"
	"github.com/mholt/archiver/v3"
)

func main()  {
	//Создаем каталоги для измененных проектов
	z := archiver.Zip{
		CompressionLevel:       flate.DefaultCompression,
		MkdirAll:               true,
		SelectiveCompression:   true,
		ContinueOnError:        false,
		OverwriteExisting:      false,
		ImplicitTopLevelFolder: false,
	}

	err := z.Archive([]string{"D:\\Projects\\toolsXela\\toolsXela\\arch2"}, "test.zip")
	fmt.Println(err)

}


